		var flashvars={
			VideoIDS:ylmb,f:ylurl,c:ylcall,p:ylplay,e:ylfunction,i:ylpicture,d:ylStopad,u:ylStopadurl,l:ylplayad,r:ylplayadurl,t:ylplayadtime,
			my_url:encodeURIComponent(window.location.href)+ylmb,
			loaded:'loadedHandler'
		};
		var video = [ylurl+'->video/mp4'];
CKobject.embed('http://www.cn1010.com/Player/YuLeTV.swf','YuLeTV_Player','YuLeTV_a1',ylwidth,ylheight,false,flashvars,video);
		
		
		
		
		
		
		
		
		
		
		
		
		


